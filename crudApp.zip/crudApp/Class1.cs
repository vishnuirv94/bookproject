﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crudApp.Entities
{
    public class Book
    {
        public string name { get; set; }
        public string author { get; set; }
        public int bookid { get; set; }
        public long isbn { get; set; }
        public long price { get; set; }
    }
}
